const {Schema, model} = require('mongoose');

const instrumentoSchema = new Schema ({
    // descripcion: String,
    // cantidad: Number,
    tipoid: {type: String, require: true},
    _id: Number,
    clave: Password,
    rol: "",
    activado: "",
    desactivado: "",
    activo: "",
    fijo: "",
    celular: "",
    correo: "",
    direccion: "",
    tipoPersona: "",
    nombre: "",
    apellido: "",
});

module.exports = model('Productos', instrumentoSchema);