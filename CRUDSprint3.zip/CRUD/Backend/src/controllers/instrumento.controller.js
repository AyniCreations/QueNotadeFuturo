const Instrumento = require('../models/instrumento.modelo');
const instrumentoCtrl = {};

instrumentoCtrl.getInstrumentos = async (req, res) =>{
    const instrumentos = await Instrumento.find();
    res.json(instrumentos);
}

instrumentoCtrl.createInstrumento = async (req, res) =>{
    const {tipoInstrumento, instrumento, precio, descripcion, cantidad} = req.body;
    const newInstrumento = new Instrumento({
        tipoInstrumento,
        instrumento,
        precio,
        descripcion,
        cantidad
        
    });
    await newInstrumento.save();
    res.json('Instrumento añadido')
}

instrumentoCtrl.getInstrumento = async(req,res)=>{
    const instrumento = await Instrumento.findById(req.params.id)
    res.json(instrumento)
}

instrumentoCtrl.getInstrumentop = async(req,res)=>{
    const instrumento = await Instrumento.findByprecio(req.params.precio)
    res.json(instrumento)
}

instrumentoCtrl.deleteInstrumento = async(req, res)=>{
    await Instrumento.findByIdAndDelete(req.params.id)
    res.json('Instrumento eliminado')
}

instrumentoCtrl.updateInstrumento = async(req, res)=>{
    const{tipoInstrumento, instrumento, descripcion, precio, cantidad} = req.body;
    await Instrumento.findByIdAndUpdate(req.params.id,
        {tipoInstrumento, instrumento, descripcion, precio, cantidad }
        )
        res.json('Instrumento actualizado');
}

module.exports = instrumentoCtrl;