const Donador = require('../models/donador.modelo');
const donadorCtrl = {};

donadorCtrl.getDonadores = async (req, res) =>{
    const donadores = await Donador.find();
    res.json(donadores);
}

donadorCtrl.createDonador = async (req, res) =>{
    const {tipoInstrumento, instrumento, precio, descripcion, cantidad} = req.body;
    const newInstrumento = new Donador({
        tipoInstrumento,
        instrumento,
        precio,
        descripcion,
        cantidad
        
    });
    await newInstrumento.save();
    res.json('Donador añadido')
}

donadorCtrl.getDonador = async(req,res)=>{
    const donador = await Donador.findById(req.params.id)
    res.json(donador)
}

donadorCtrl.getDonadorp = async(req,res)=>{
    const donador = await Donador.findByprecio(req.params.precio)
    res.json(donador)
}

donadorCtrl.deleteDonador = async(req, res)=>{
    await Donador.findByIdAndDelete(req.params.id)
    res.json('Donador eliminado')
}

donadorCtrl.updateDonador = async(req, res)=>{
    const{tipoInstrumento, instrumento, descripcion, precio, cantidad} = req.body;
    await Instrumento.findByIdAndUpdate(req.params.id,
        {tipoInstrumento, instrumento, descripcion, precio, cantidad }
        )
        res.json('Donador actualizado');
}

module.exports = donadorCtrl;