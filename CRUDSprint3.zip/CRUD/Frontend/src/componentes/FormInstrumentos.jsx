import React, { Component } from "react";
import { Col, Container } from "reactstrap";
import './Formulario.css';
//import 'bootstrap/dist/css/bootstrap.min.css';

export class FormInstrumentos extends Component {
  constructor() {
    super();
    this.state = {
      tipoInstrumento: "",
      instrumento: "",
      descripción: "",
      precio: "",
      cantidad: "",
      instrumentos: [],
    };
    this.handleChange = this.handleChange.bind(this);
    this.agregarInstrumento = this.agregarInstrumento.bind(this);
  }
  handleChange(e) {
    const { name, value } = e.target;
    this.setState({
      [name]: value,
    });
  }

  componentDidMount() {
    this.fetchInstrumentos();
  }
  fetchInstrumentos() {
    fetch("http://localhost:4000/api/instrumentos")
      .then(res => res.json())
      .then(data => {
        this.setState({ instrumentos: data });
        console.log(this.state.instrumentos);
      });
  }

  deleteInstrumento(id) {
    if (window.confirm('Realmente desea eliminar el Instrumento?')) {
      fetch(`http://localhost:4000/api/instrumentos/${id}`, {
        method: "DELETE",
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
        },
      })
        .then((res) => res.json())
        .then((data) => {
          console.log(data);
          alert("Instrumento eliminado");
          this.fetchInstrumentos();
        });
    }

  }

  editInstrumento(id) {
    fetch(`http://localhost:4000/api/instrumentos/${id}`)
      .then(res => res.json())
      .then(data => {
        console.log(data);
        this.setState({
          tipoInstrumento: data.tipoInstrumento,
          instrumento: data.instrumento,
          descripción: data.descripcion,
          precio: data.precio,
          cantidad: data.cantidad,
        });
      });
  }

  agregarInstrumento(e) {
    e.preventDefault();
    if (this.state._id) {
      fetch(`http://localhost:4000/api/instrumentos/${this.state._id}`, {
        method: "PUT",
        body: JSON.stringify({
          tipoInstrumento: this.state.tipoInstrumento,
          instrumento: this.state.instrumento,
          descripción: this.state.descripcion,
          precio: this.state.precio,
          cantidad: this.state.cantidad,
        }),
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json"
        },
      })
        .then(res => res.json)
        .then(data => {
          console.log(data)
          alert("Instrumento actualizado");
          this.setState({
            tipoInstrumento: "",
            instrumento: "",
            descripción: "",
            precio: "",
            cantidad: "",
          });
          this.fetchInstrumentos();
        });
    } else {
      fetch("http://localhost:4000/api/instrumentos", {
        method: "POST",
        body: JSON.stringify(this.state),
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json"
        },
      })
        .then(res => res.json())
        .then(data => {
          console.log(data);
          alert("Instrumento creado");
          this.fetchInstrumentos();
        });
    }
  }

  render() {
    return (
      <Container>
        <Col sm="6">
          <h4>Nuevo Instrumento</h4>
          <form onSubmit={this.agregarInstrumento}>
          <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
            <div className="form-group">
              <select className="form-select mb-3"
                required placeholder="Ingrese Identificación"
                onChange={this.handleChange}
                value={this.state.tipoInstrumento}>
                <option selected>Tipo Instrumento</option>
                <option value="1">Cuerda</option>
                <option value="2">Percusión</option>
                <option value="3">Viento</option>
              </select>
            </div>
            <br></br>
            <div className="mb-3">
              <input
                name="descripcion"
                className="form-control"
                type="text"
                required placeholder="Instrumento"
                onChange={this.handleChange}
                value={this.state.instrumento}
              />
            </div>
            <div className="mb-3">
              <input
                name="descripcion"
                className="form-control"
                type="text"
                placeholder="Ingrese descripcion"
                onChange={this.handleChange}
                value={this.state.descripcion}
              />
            </div>
            <div className="mb-3">
              <input
                name="precio"
                className="form-control"
                type="text"
                placeholder="Ingrese el precio"
                onChange={this.handleChange}
                value={this.state.precio}
              />
            </div>
            <div className="mb-3">
              <input
                name="cantidad"
                className="form-control"
                type="number"
                placeholder="Ingrese cantidad"
                onChange={this.handleChange}
                value={this.state.cantidad}
              />
            </div>
            <button type="submit" className="btn btn-primary">
              Guardar
            </button>
            </form>
        </Col>
        <Col sm="10">
          <h4>Lista de instrumentos</h4>
          <table className="table">
            <thead>
              <tr>
                <th>Tipo instrumento</th>
                <th>Instrumento</th>
                <th>Desripcion</th>
                <th>Precio</th>
                <th>Cantidad</th>
              </tr>
            </thead>
            <tbody>
              {this.state.instrumentos.map((Instrumento) => {
                return (
                  <tr key={Instrumento._id}>
                    <td>{Instrumento.tipoinstrumento}</td>
                    <td>{Instrumento.instrumento}</td>
                    <td>{Instrumento.descripcion}</td>
                    <td>{Instrumento.precio}</td>
                    <td>{Instrumento.cantidad}</td>
                    <td>
                      <button
                        onClick={() => this.editInstrumento(Instrumento._id)}
                        type="button"
                        className="btn btn-info"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => this.deleteInstrumento(Instrumento._id)}
                        type="button"
                        className="btn btn-danger"
                      >
                        Borrar
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Col>
      </Container>
    );
  }
}
