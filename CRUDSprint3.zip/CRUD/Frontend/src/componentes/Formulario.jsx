import React, { Component } from "react";
import { Col, Container } from "reactstrap";
import './Formulario.css';

export class Formulario extends Component {
  constructor() {
    super();
    this.state = {
      tipoid: "",
      _id: "",
      clave: "",
      rol: "",
      activado: "",
      desactivado: "",
      activo: "",
      fijo: "",
      celular: "",
      correo: "",
      direccion: "",
      tipoPersona: "",
      nombre: "",
      apellido: "",
      donadores: [],
    };
    this.handleChange = this.handleChange.bind(this);
    this.agregarDonador = this.agregarDonador.bind(this);
  }
  handleChange(e) {
    const { name, value } = e.target;
    this.setState({
      [name]: value,
    });
  }

  componentDidMount() {
    this.fetchDonadores();
  }
  fetchDonadores() {
    fetch("http://localhost:4000/api/donadores")
      .then(res => res.json())
      .then(data => {
        this.setState({ donadores: data });
        console.log(this.state.donadores);
      });
  }

  deleteDonador(id) {
    if (window.confirm('Realmente desea eliminar el Donador?')) {
      fetch(`http://localhost:4000/api/donadores/${id}`, {
        method: "DELETE",
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
        },
      })
        .then(res => res.json())
        .then(data => {
          console.log(data);
          alert("Donador eliminado");
          this.fetchDonadores();
        });
    }
  }

  editDonador(id) {
    fetch(`http://localhost:4000/api/donadores/${id}`)
      .then(res => res.json())
      .then(data => {
        console.log(data);
        this.setState({
          tipoid: data.tipoid,
          _id: data._id,
          clave: data.clave,
          rol: data.rol,
          activado: data.activado,
          desactivado: data.desactivado,
          activo: data.activo,
          fijo: data.fijo,
          celular: data.celular,
          correo: data.correo,
          direccion: data.dirección,
          tipoPersona: data.tipoPersona,
          nombre: data.nombre,
          apellido: data.apellido,
        });
      });
  }

  agregarDonador(e) {
    e.preventDefault();
    if (this.state._id) {
      fetch(`http://localhost:4000/api/donadores/${this.state._id}`, {
        method: "PUT",
        body: JSON.stringify({
          tipoid: this.state.tipoid,
          _id: this.state._id,
          clave: this.state.clave,
          rol: this.state.rol,
          activado: this.state.activado,
          desactivado: this.state.desactivado,
          activo: this.state.activo,
          fijo: this.state.fijo,
          celular: this.state.celular,
          correo: this.state.correo,
          direccion: this.state.direccion,
          tipoPersona: this.state.tipoPersona,
          nombre: this.state.nombre,
          apellido: this.state.apellido,
        }),
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json"
        },
      })
        .then(res => res.json)
        .then(data => {
          console.log(data);
          alert("Donador actualizado");
          this.setState({
            tipoid: "",
            _id: "",
            clave: "",
            rol: "",
            activado: "",
            desactivado: "",
            activo: "",
            fijo: "",
            celular: "",
            correo: "",
            direccion: "",
            tipoPersona: "",
            nombre: "",
            apellido: "",
          });
          this.fetchDonadores();
        });
    } else {
      fetch("http://localhost:4000/api/donadores", {
        method: "POST",
        body: JSON.stringify(this.state),
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json"
        },
      })
        .then(res => res.json())
        .then(data => {
          console.log(data);
          alert("Donador creado");
          this.fetchDonadores();
        });
    }
  }

  render() {
    return (
      <Container>
        <Col sm="6">
          <h4>Nuevo Donador</h4>
            <form onSubmit={this.agregarDonador}>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <div className="form-group">
                  <select className="form-select mb-3"
                    required placeholder="Ingrese Identificación"
                    onChange={this.handleChange}
                    value={this.state.tipoid}>
                    <option selected>Tipo Identificación</option>
                    <option value="1">CC</option>
                    <option value="2">CE</option>
                    <option value="3">RUT</option>
                    <option value="4">NIT</option>
                  </select>
                </div>
                <div className="mb-3">
                  <input
                    type="number"
                    className="form-control"
                    id="_id"
                    required placeholder="Identificación"
                    onChange={this.handleChange}
                    value={this.state._id}
                  />
                </div>
                <div className="mb-3">
                  <input
                    type="password"
                    className="form-control"
                    required placeholder="Clave"
                    onChange={this.handleChange}
                    value={this.state.clave}
                  />
                </div>
                <div className="mb-3">
                  <select className="form-select"
                    required placeholder="Rol"
                    onChange={this.handleChange}
                    value={this.state.activo}>
                    <option selected>Tipo Identificación</option>
                    <option value="1">Administrador</option>
                    <option value="2">Donador</option>
                  </select>
                </div>
                <div className="mb-3">
                  <input
                    type="date"
                    className="form-control"
                    required placeholder="Activado"
                    onChange={this.handleChange}
                    value={this.state.activado}
                  />
                </div>
                <div className="mb-3">
                  <input
                    type="date"
                    className="form-control"
                    required placeholder="Desactivado"
                    onChange={this.handleChange}
                    value={this.state.desactivo}
                  />
                </div>
                <div className="mb-3">
                  <input
                    type="boolean"
                    className="form-control"
                    required placeholder="Activo"
                    onChange={this.handleChange}
                    value={this.state.activo}
                  />
                </div>
                <div className="mb-3">
                  <select className="form-select"
                    required placeholder="Tipo de persona"
                    onChange={this.handleChange}
                    value={this.state.activo}>
                    <option selected>Tipo Persona</option>
                    <option value="1">Natural</option>
                    <option value="2">Juridica</option>
                  </select>
                </div>
                <div className="mb-3">
                  <input
                    type="text"
                    className="form-control"
                    required placeholder="Nombre"
                    onChange={this.handleChange}
                    value={this.state.nombre}
                  />
                </div>
                <div className="mb-3">
                  <input
                    type="text"
                    className="form-control"
                    required placeholder="Apellido"
                    onChange={this.handleChange}
                    value={this.state.apellido}
                  />
                </div>
                <div className="mb-3">
                  <input
                    type="number"
                    className="form-control"
                    required placeholder="Teléfono Fijo"
                    onChange={this.handleChange}
                    value={this.state.fijo}
                  />
                </div>
                <div className="mb-3">
                  <input
                    type="number"
                    className="form-control"
                    required placeholder="Celular"
                    onChange={this.handleChange}
                    value={this.state.celular}
                  />
                </div>
                <div className="mb-3">
                  <input
                    type="mongoose"
                    className="form-control"
                    required placeholder="E-mail"
                    onChange={this.handleChange}
                    value={this.state.email}
                  />
                </div>
                <div className="mb-3">
                  <input
                    type="text"
                    className="form-control"
                    required placeholder="Dirección"
                    onChange={this.handleChange}
                    value={this.state.direccion}
                  />
                </div>
                <button type="submit" className="btn btn-primary">
                  Guardar
                </button>
              </form>
            </Col>
            <Col sm="10">
              <h4>Lista de donadores</h4>
              <table className="table">
                <thead>
                  <tr>
                    <th>Tipoid</th>
                    <th>_id</th>
                    <th>Clave</th>
                    <th>Rol</th>
                    <th>Activado</th>
                    <th>Desactivado</th>
                    <th>Activo</th>
                    <th>Fijo</th>
                    <th>Celular</th>
                    <th>Correo</th>
                    <th>Direccion</th>
                    <th>TipoPersona</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                  </tr>
                </thead>
                <tbody>
                  {this.state.donadores.map((Donador) => {
                    return (
                      <tr key={Donador._id}>
                        <td>{Donador.tipoid}</td>
                        <td>{Donador.clave}</td>
                        <td>{Donador.rol}</td>
                        <td>{Donador.activado}</td>
                        <td>{Donador.desactivado}</td>
                        <td>{Donador.activo}</td>
                        <td>{Donador.fijo}</td>
                        <td>{Donador.celular}</td>
                        <td>{Donador.correo}</td>
                        <td>{Donador.direccion}</td>
                        <td>{Donador.tipoPersona}</td>
                        <td>{Donador.nombre}</td>
                        <td>{Donador.apellido}</td>
                        <td>
                          <button
                            onClick={() => this.editDonador(Donador._id)}
                            type="button"
                            className="btn btn-info"
                          >
                            Editar
                          </button>
                          <button
                            onClick={() => this.deleteDonador(Donador._id)}
                            type="button"
                            className="btn btn-danger"
                          >
                            Borrar
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
        </Col>
      </Container>
    );
  }
}

//export default Formulario;